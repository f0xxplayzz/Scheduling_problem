---
name: Request a Feature in Gecode
about: Suggest a new feasture

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]
**Describe the Feature**

Please describe the feature in as much detail as you can.

**Why Is the Requested Feature Useful?**

Please argue why the feature is useful to you and _others_.
