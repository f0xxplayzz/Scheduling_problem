@mainpage Quacode

\b Quacode is a Quantified Constraint Satisfaction Problems (QCSP) solver built over the [Gecode](http://www.gecode.org) toolkit.
